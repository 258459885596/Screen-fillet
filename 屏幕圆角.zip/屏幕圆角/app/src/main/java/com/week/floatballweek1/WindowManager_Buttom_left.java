package com.week.floatballweek1;

import android.content.Context;
import android.graphics.PixelFormat;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.view.*;
import android.util.*;
import java.lang.reflect.*;

public class WindowManager_Buttom_left{
    public static Buttom_left View_Image;
	public static LayoutParams params;
    public static WindowManager mWindowManager;
	public static WindowManager windowManager;
    public static void addBallView(Context context) {
        if (View_Image == null) {
            windowManager = getWindowManager(context);
            View_Image = new Buttom_left(context);
            params = new LayoutParams();
            params.x = 0;
            params.y = 0;
            params.width = 0;
            params.height = 0;
            params.gravity = Gravity.BOTTOM|Gravity.LEFT;
            params.type = LayoutParams.TYPE_SYSTEM_OVERLAY;
            params.format = PixelFormat.RGBA_8888;
            params.flags = LayoutParams.FLAG_NOT_TOUCH_MODAL
				|LayoutParams.FLAG_NOT_FOCUSABLE
				|LayoutParams.FLAG_NOT_TOUCHABLE
				|LayoutParams.FLAG_LAYOUT_NO_LIMITS
				|LayoutParams.FLAG_LAYOUT_IN_SCREEN;
            View_Image.setLayoutParams(params);
            windowManager.addView(View_Image, params);
        }
    }

    public static void removeBallView(Context context) {
        if (View_Image != null) {
            WindowManager windowManager = getWindowManager(context);
            windowManager.removeView(View_Image);
            View_Image = null;
        }
    }

    private static WindowManager getWindowManager(Context context) {
        if (mWindowManager == null) {
            mWindowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        }
        return mWindowManager;
    }

}
