package com.week.floatballweek1;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.os.Vibrator;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import java.lang.reflect.Field;
import android.view.ViewGroup.LayoutParams;
import android.widget.*;

public class Top_left extends LinearLayout {
    public static ImageView ima;
    private WindowManager mWindowManager;
    private Vibrator mVibrator;
	 
    public Top_left(Context context){
        super(context);
        mVibrator = (Vibrator) getContext().getSystemService(Context.VIBRATOR_SERVICE);
        mWindowManager = (WindowManager) getContext().getSystemService(Context.WINDOW_SERVICE);
        initView();
    }

    private void initView() {
        inflate(getContext(), R.layout.top_left, this);
        ima = (ImageView) findViewById(R.id.top_leftImageView);
    }

}
