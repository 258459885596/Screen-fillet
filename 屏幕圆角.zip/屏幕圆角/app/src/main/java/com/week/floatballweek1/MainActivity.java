package com.week.floatballweek1;

import android.app.*;
import android.os.*;
import android.view.*;
import android.graphics.*;
import android.widget.*;
import android.view.View.*;
import android.widget.SeekBar.*;
import android.util.Log;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageView;
import android.content.*;
import android.util.*;
import java.lang.reflect.*;
import com.week.floatballweek1.permission.*;
import android.content.pm.*;
import android.net.*;

public class MainActivity extends Activity{
	public Switch mSwitch;
	public SeekBar SeekBar1;
	public SeekBar SeekBar2;
	public TextView TextView1;
	public TextView TextView2;
	public CheckBox CheckBox1;
	public CheckBox CheckBox2;
	public CheckBox CheckBox3;
	public CheckBox CheckBox4;
	public int CHECKBOX1 = 0;
	public int CHECKBOX2 = 0;
	public int CHECKBOX3 = 0;
	public int CHECKBOX4 = 0;
	public int r, g,b,a;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.main);
		Intent whiteIntent = new Intent(getApplicationContext(), WhiteService.class);
		startService(whiteIntent);
		DetectionofsuspendedPermissions();//
		TextView1 = (TextView)findViewById(R.id.mainTextView1);
		TextView1.setText(0+"");
		TextView2 = (TextView)findViewById(R.id.mainTextView2);
		TextView2.setText(255+"");
		setWindowStatusBarColor(this, R.color.colorPrimary);//
		//
		mSwitch = (Switch)findViewById(R.id.mainSwitch);
		mSwitch.setOnCheckedChangeListener(new Switch.OnCheckedChangeListener(){
				@Override
				public void onCheckedChanged(CompoundButton p1, boolean p2){
					if(p2){
						WindowManager_Top_left.addBallView(MainActivity.this);
						WindowManager_Top_right.addBallView(MainActivity.this);
						WindowManager_Buttom_left.addBallView(MainActivity.this);
						WindowManager_Buttom_right.addBallView(MainActivity.this);
						CHECKBOX1 = 1;
						CHECKBOX2 = 1;
						CHECKBOX3 = 1;
						CHECKBOX4 = 1;
						if(isNavigationBarShow() == true){
							WindowManager_Buttom_left.params.y=-getVirtualBarHeigh(MainActivity.this);
							WindowManager_Buttom_right.params.y=-getVirtualBarHeigh(MainActivity.this);
							WindowManager_Buttom_left.windowManager.updateViewLayout(WindowManager_Buttom_left.View_Image,WindowManager_Buttom_left.params);
							WindowManager_Buttom_right.windowManager.updateViewLayout(WindowManager_Buttom_right.View_Image,WindowManager_Buttom_right.params);
						}else if(isNavigationBarShow() == false){
							WindowManager_Buttom_left.params.y=0;
							WindowManager_Buttom_right.params.y=0;
							WindowManager_Buttom_left.windowManager.updateViewLayout(WindowManager_Buttom_left.View_Image,WindowManager_Buttom_left.params);
							WindowManager_Buttom_right.windowManager.updateViewLayout(WindowManager_Buttom_right.View_Image,WindowManager_Buttom_right.params);
						}
					}else{
						WindowManager_Top_left.removeBallView(MainActivity.this);
						WindowManager_Top_right.removeBallView(MainActivity.this);
						WindowManager_Buttom_left.removeBallView(MainActivity.this);
						WindowManager_Buttom_right.removeBallView(MainActivity.this);
						CHECKBOX1 = 0;
						CHECKBOX2 = 0;
						CHECKBOX3 = 0;
						CHECKBOX4 = 0;
					}
				}
			});
		//
		findViewById(R.id.mainImageButton).setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1){
					Color();
				}
			});
		//
		findViewById(R.id.Button1).setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1){
					donateAlipay("FKX05285W1LFPENPWLZC52");
				}
			});
		//
		findViewById(R.id.Button2).setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1){
					if (checkApkExist(MainActivity.this, "com.tencent.mobileqq")){
						startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("mqqwpa://im/chat?chat_type=wpa&uin="+1648328337+"&version=1")));
					}else{
						Toast.makeText(MainActivity.this,"本机未安装QQ应用",Toast.LENGTH_SHORT).show();
					}
				}
			});
		//
		findViewById(R.id.Button3).setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1){
					if (checkApkExist(MainActivity.this, "com.tencent.mobileqq")){
						startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("mqqapi://card/show_pslcard?src_type=internal&version=1&uin="+716446394+"&card_type=group&source=qrcode" + "&version=1")));
					}else{
						Toast.makeText(MainActivity.this,"本机未安装QQ应用",Toast.LENGTH_SHORT).show();
					}
				}
			});
		//
		findViewById(R.id.pact).setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1){
					Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
					intent.setType("image/*");
					intent.addCategory(Intent.CATEGORY_OPENABLE);
					startActivityForResult(intent,1);
				}
			});
		//
		SeekBar1 = (SeekBar)findViewById(R.id.mainSeekBar1);
		SeekBar1.setOnSeekBarChangeListener(new OnSeekBarChangeListener(){
				@Override
				public void onProgressChanged(SeekBar p1,final int p2, boolean p3){
					if (CHECKBOX1 == 1){
						WindowManager_Top_left.params.width=p2;
						WindowManager_Top_left.params.height=p2;
						WindowManager_Top_left.windowManager.updateViewLayout(WindowManager_Top_left.View_Image,WindowManager_Top_left.params);
					}if (CHECKBOX2 == 1){
						WindowManager_Top_right.params.width=p2;
						WindowManager_Top_right.params.height=p2;
						WindowManager_Top_right.windowManager.updateViewLayout(WindowManager_Top_right.View_Image,WindowManager_Top_right.params);
					}if (CHECKBOX3 == 1){
						WindowManager_Buttom_left.params.width=p2;
						WindowManager_Buttom_left.params.height=p2;
						WindowManager_Buttom_left.windowManager.updateViewLayout(WindowManager_Buttom_left.View_Image,WindowManager_Buttom_left.params);
					}if (CHECKBOX4 == 1){
						WindowManager_Buttom_right.params.width=p2;
						WindowManager_Buttom_right.params.height=p2;
						WindowManager_Buttom_right.windowManager.updateViewLayout(WindowManager_Buttom_right.View_Image,WindowManager_Buttom_right.params);
					}
					TextView1. setText(p2+"");
				}
				@Override
				public void onStartTrackingTouch(SeekBar p1){
					
				}
				@Override
				public void onStopTrackingTouch(SeekBar p1){
					
				}
			});
		SeekBar2 = (SeekBar)findViewById(R.id.mainSeekBar2);
		SeekBar2.setMax(255);
		SeekBar2.setProgress(255);
		SeekBar2.setOnSeekBarChangeListener(new OnSeekBarChangeListener(){
				@Override
				public void onProgressChanged(SeekBar p1, int p2, boolean p3){
					if (CHECKBOX1 == 1){
					Top_left.ima.setAlpha(p2);
					WindowManager_Top_left.windowManager.updateViewLayout(WindowManager_Top_left.View_Image,WindowManager_Top_left.params);
					}if (CHECKBOX2 == 1){
					Top_right.ima.setAlpha(p2);
					WindowManager_Top_right.windowManager.updateViewLayout(WindowManager_Top_right.View_Image,WindowManager_Top_right.params);
					}if (CHECKBOX3 == 1){
					Buttom_left.ima.setAlpha(p2);
					WindowManager_Buttom_left.windowManager.updateViewLayout(WindowManager_Buttom_left.View_Image,WindowManager_Buttom_left.params);
					}if (CHECKBOX4 == 1){
					Buttom_right.ima.setAlpha(p2);
					WindowManager_Buttom_right.windowManager.updateViewLayout(WindowManager_Buttom_right.View_Image,WindowManager_Buttom_right.params);
					}
					TextView2. setText(p2+"");
				}
				@Override
				public void onStartTrackingTouch(SeekBar p1){

				}
				@Override
				public void onStopTrackingTouch(SeekBar p1){

				}
			});
		CheckBox1 = (CheckBox)findViewById(R.id.mainCheckBox1);
		CheckBox1.setChecked(true);
		CheckBox1.setOnCheckedChangeListener(new CheckBox.OnCheckedChangeListener(){
				@Override
				public void onCheckedChanged(CompoundButton p1, boolean p2){
					if(p2){
						WindowManager_Top_left.addBallView(MainActivity.this);
						CHECKBOX1 = 1;
					}else{
						WindowManager_Top_left.removeBallView(MainActivity.this);
						CHECKBOX1 = 0;
					}
				}
			});
		CheckBox2 = (CheckBox)findViewById(R.id.mainCheckBox2);
		CheckBox2.setChecked(true);
		CheckBox2.setOnCheckedChangeListener(new CheckBox.OnCheckedChangeListener(){
				@Override
				public void onCheckedChanged(CompoundButton p1, boolean p2){
					if(p2){
						WindowManager_Top_right.addBallView(MainActivity.this);
						CHECKBOX2 = 1;
					}else{
						WindowManager_Top_right.removeBallView(MainActivity.this);
						CHECKBOX2 = 0;
					}
				}
			});
		CheckBox3 = (CheckBox)findViewById(R.id.mainCheckBox3);
		CheckBox3.setChecked(true);
		CheckBox3.setOnCheckedChangeListener(new CheckBox.OnCheckedChangeListener(){
				@Override
				public void onCheckedChanged(CompoundButton p1, boolean p2){
					if(p2){
						WindowManager_Buttom_left.addBallView(MainActivity.this);
						CHECKBOX3 = 1;
					}else{
						WindowManager_Buttom_left.removeBallView(MainActivity.this);
						CHECKBOX3 = 0;
					}
				}
			});
		CheckBox4 = (CheckBox)findViewById(R.id.mainCheckBox4);
		CheckBox4.setChecked(true);
		CheckBox4.setOnCheckedChangeListener(new CheckBox.OnCheckedChangeListener(){
				@Override
				public void onCheckedChanged(CompoundButton p1, boolean p2){
					if(p2){
						WindowManager_Buttom_right.addBallView(MainActivity.this);
						CHECKBOX4 = 1;
					}else{
						WindowManager_Buttom_right.removeBallView(MainActivity.this);
						CHECKBOX4 = 0;
					}
				}
			});
    }
	//
	public void DetectionofsuspendedPermissions(){
		FloatWindowManager.getInstance().applyOrShowFloatWindow(MainActivity.this);
	}
	
	//
	public static void setWindowStatusBarColor(Activity activity, int colorResId){
		try{
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
				Window window = activity.getWindow();
				window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
				window.setStatusBarColor(activity.getResources().getColor(colorResId));
			}
		}
		catch (Exception e){
			e.printStackTrace();
		}
	}

	//
	public boolean isNavigationBarShow(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            Display display = this.getWindowManager().getDefaultDisplay();
            Point size = new Point();
            Point realSize = new Point();
            display.getSize(size);
            display.getRealSize(realSize);
            boolean  result  = realSize.y!=size.y;
            return realSize.y!=size.y;
        }else {
            boolean menu = ViewConfiguration.get(this).hasPermanentMenuKey();
            boolean back = KeyCharacterMap.deviceHasKey(KeyEvent.KEYCODE_BACK);
            if(menu || back) {
                return false;
            }else {
                return true;
            }
        }
    }
	
	//
	public static int getVirtualBarHeigh(Context context) {
        int vh = 0;
        WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = windowManager.getDefaultDisplay();
        DisplayMetrics dm = new DisplayMetrics();
        try {
            @SuppressWarnings("rawtypes")
				Class c = Class.forName("android.view.Display");
            @SuppressWarnings("unchecked")
				Method method = c.getMethod("getRealMetrics", DisplayMetrics.class);
            method.invoke(display, dm);
            vh = dm.heightPixels - windowManager.getDefaultDisplay().getHeight();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return vh;
    }
	
	private void Color() {
		AlertDialog.Builder customizeDialog = 
			new AlertDialog.Builder(MainActivity.this);
		final View dialogView = LayoutInflater.from(MainActivity.this)
			.inflate(R.layout.color,null);
		customizeDialog.setView(dialogView);
		final TextView colorTextView = (TextView)dialogView.findViewById(R.id.colorBackground);
		colorTextView.setBackgroundColor(Color.argb(255,0,0,0));
		final TextView colorTextView1 = (TextView)dialogView.findViewById(R.id.colorTextView1);
		colorTextView1.setText(0+"");
		final TextView colorTextView2 = (TextView)dialogView.findViewById(R.id.colorTextView2);
		colorTextView2.setText(0+"");
		final TextView colorTextView3 = (TextView)dialogView.findViewById(R.id.colorTextView3);
		colorTextView3.setText(0+"");
		SeekBar colorSeekBar1 = (SeekBar)dialogView.findViewById(R.id.colorSeekBar1);
		colorSeekBar1.setMax(255);
		colorSeekBar1.setProgress(0);
		colorSeekBar1.setOnSeekBarChangeListener(new OnSeekBarChangeListener(){
				@Override
				public void onProgressChanged(SeekBar p1, int p2, boolean p3){
					
					String f = Integer.toString(p2);
					colorTextView1.setText(f+"");
					a=Integer.parseInt((String) colorTextView1.getText());
					g = Integer.parseInt((String) colorTextView2.getText());
					b = Integer.parseInt((String) colorTextView3.getText());
					colorTextView.setBackgroundColor(Color.argb(255,p2, g, b));
					Top_left.ima.setColorFilter(Color.argb(255,p2,g,b));
					Top_right.ima.setColorFilter(Color.argb(255,p2,g,b));
					Buttom_left.ima.setColorFilter(Color.argb(255,p2,g,b));
					Buttom_right.ima.setColorFilter(Color.argb(255,p2,g,b));
				}
				@Override
				public void onStartTrackingTouch(SeekBar p1){}
				@Override
				public void onStopTrackingTouch(SeekBar p1){}
			});
		SeekBar colorSeekBar2 = (SeekBar)dialogView.findViewById(R.id.colorSeekBar2);
		colorSeekBar2.setMax(255);
		colorSeekBar2.setProgress(0);
		colorSeekBar2.setOnSeekBarChangeListener(new OnSeekBarChangeListener(){
				@Override
				public void onProgressChanged(SeekBar p1, int p2, boolean p3){
					String y = Integer.toString(p2);
					colorTextView2.setText(y+"");
					a=Integer.parseInt((String) colorTextView1.getText());
					r = Integer.parseInt((String) colorTextView1.getText());
					b = Integer.parseInt((String) colorTextView3.getText());
					colorTextView.setBackgroundColor(Color.argb(255,r, p2, b));
					Top_left.ima.setColorFilter(Color.argb(255,r,p2,b));
					Top_right.ima.setColorFilter(Color.argb(255,r,p2,b));
					Buttom_left.ima.setColorFilter(Color.argb(255,r,p2,b));
					Buttom_right.ima.setColorFilter(Color.argb(255,r,p2,b));
				}
				@Override
				public void onStartTrackingTouch(SeekBar p1){}
				@Override
				public void onStopTrackingTouch(SeekBar p1){}
			});
		SeekBar colorSeekBar3 = (SeekBar)dialogView.findViewById(R.id.colorSeekBar3);
		colorSeekBar3.setMax(255);
		colorSeekBar3.setProgress(0);
		colorSeekBar3.setOnSeekBarChangeListener(new OnSeekBarChangeListener(){
				@Override
				public void onProgressChanged(SeekBar p1, int p2, boolean p3){
					
					String p = Integer.toString(p2);
					colorTextView3.setText(p+"");
					r = Integer.parseInt((String) colorTextView1.getText());
					g = Integer.parseInt((String) colorTextView1.getText());
					a=Integer.parseInt((String) colorTextView1.getText());
					colorTextView.setBackgroundColor(Color.argb(255,r, g, p2));
					Top_left.ima.setColorFilter(Color.argb(255,r,g,p2));
					Top_right.ima.setColorFilter(Color.argb(255,r,g,p2));
					Buttom_left.ima.setColorFilter(Color.argb(255,r,g,2));
					Buttom_right.ima.setColorFilter(Color.argb(255,r,g,2));
				}
				@Override
				public void onStartTrackingTouch(SeekBar p1){}
				@Override
				public void onStopTrackingTouch(SeekBar p1){}
			});
		customizeDialog.setPositiveButton("确定",
			new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					
				}
			});
		customizeDialog.setNegativeButton("取消", new DialogInterface.OnClickListener(){
				@Override
				public void onClick(DialogInterface p1, int p2){
					
				}
			});
		customizeDialog.show();
	}
	//
	public boolean checkApkExist(Context context, String packageName) {
        if (packageName == null || "".equals(packageName))
			return false;
        try {
            ApplicationInfo info = context.getPackageManager().getApplicationInfo(packageName,
																				  PackageManager.GET_UNINSTALLED_PACKAGES);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }
	//
	private void donateAlipay(String payCode) {
        boolean hasInstalledAlipayClient = AlipayDonate.hasInstalledAlipayClient(this);
        if (hasInstalledAlipayClient) {
            AlipayDonate.startAlipayClient(this, payCode);
        }
    }
	
	//
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		if (resultCode == Activity.RESULT_OK) {
			if (requestCode == 1) {
				Uri uri = data.getData();
				Top_left.ima.setImageURI(uri);
				Top_right.ima.setImageURI(uri);
				Buttom_left.ima.setImageURI(uri);
				Buttom_right.ima.setImageURI(uri);
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	//
	public void Time(String s){
		Toast.makeText(this, s, Toast.LENGTH_LONG).show();
	}

}
